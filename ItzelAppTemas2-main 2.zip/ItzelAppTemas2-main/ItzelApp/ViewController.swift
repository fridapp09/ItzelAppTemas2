//
//  ViewController.swift
//  ItzelApp
//
//  Created by UDLAP23 on 11/04/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var logoTitle: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func logInButton(_ sender: UIButton) {
    }
    
    @IBAction func signUpButton(_ sender: UIButton) {
    }
    
}
